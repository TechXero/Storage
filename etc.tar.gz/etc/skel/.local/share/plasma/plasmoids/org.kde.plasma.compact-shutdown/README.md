# org.kde.plasma.compact-shutdown
Compact Shutdown Widget for Plasma
