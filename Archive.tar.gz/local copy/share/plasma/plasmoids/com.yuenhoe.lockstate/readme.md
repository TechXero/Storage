**Plasma 5 applet that shows the state of Caps/Num Locks**

To install:

 - Clone/download to a local folder/LockState

 - Run plasmapkg2 --install localfolder/LockState
